public class Exercise10_06 {
	
	// boolean method that determines if the number is a prime or not
	
	public static boolean findPrime(int k) {
		
		for(int j = 2; j < 120; j++)
		{
			if(k % j == 0)
			{
				return false;
			}
		}
		
		return true;
	}
	
	public static void main(String [] args) {
		
		StackOfIntegers primes = new StackOfIntegers();
		
		// going through each possible prime number under 120
		
		for(int i = 2; i < 120; i++)
		{
			if(findPrime(i) == true)
			{
				primes.push(i);
			}
		}
		
		// displaying the numbers in the stack (LIFO makes it in decending order)
		
		System.out.println("The prime numbers less than 120 in decending order is: ");
		while(!primes.empty())
		{
			System.out.print(primes.pop() + " ");
		}
	}
}