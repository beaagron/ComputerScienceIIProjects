import java.util.ArrayList;
import java.util.Scanner;

public class Exercise11_13 {
	
	public static void removeDuplicate(ArrayList<Integer> list)
	{
		
		// sorting the array to remove duplicates
		
		for(int i = 0; i < list.size() -1; i++)
		{
			for(int j = 0; j < list.size() -1 - i; j++)
			{
				if(list.get(j) > list.get(j + 1))
				{
					int temp = list.get(j);
					list.set(j, list.get(j + 1));
					list.set(j + 1, temp);
				}
			}
		}
		
		// removing the duplicates using nested loops
		
		for(int i = 0; i < list.size() - 1; i++)
		{
			if(list.get(i) == list.get(i + 1))
			{
				list.remove(i);
			}
		}
	}
	
	public static void main(String [] args)
	{
		Scanner input = new Scanner(System.in);
		ArrayList<Integer> list = new ArrayList<Integer>();
		
		// asking user for numbers and adding them to the list
		
		System.out.print("Enter ten integers: ");
		for(int i = 0; i < 10; i++)
		{
			list.add(input.nextInt());
		}
		
		// running through function and returning results
		
		System.out.print("The distinct integers are ");
		removeDuplicate(list);
		for(int i = 0; i < list.size(); i++)
		{
			System.out.print(list.get(i));
			System.out.print(" ");
		}
		
	}
}