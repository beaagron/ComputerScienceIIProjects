
public class Account {
	private int id = 0;
    private double balance = 0.0;
    private static double annualInterestRate = 0.0;
   
    public Account(){
       
    }
   
    // Refer current class instance variable: id and balance
    public Account(int id, double balance){
        this.id = id;
        this.balance = balance;
    }// Account
   
    // Get method for id
    public int getId(){
        return id;
    }// getId
   
    // Set method for id
    public void setId(int id){
        this.id = id;
    }// setId
   
    // Get method for balance
    public double getBalance(){
        return balance;
    }// getBalance
   
    // Set method for balance
    public void setBalance(double balance){
        this.balance = balance;
    }// setBalance
   
    // Get method for annualInterestRate
    public double getAnnualInterestRate(){
        return annualInterestRate;
    }// getAnnualInterestRate
   
    // Set method for annualInterestRate
    public void setAnnualInterestRate(double annualInterestRate){
        this.annualInterestRate = annualInterestRate;
    }// setAnnualInterestRate
   
    // Calculates monthlyInterestRate = (annualInterestRate / 100) /12
    public double getMonthlyInterestRate(){
        return ((annualInterestRate / 100) / 12);
    }// getMonthlyInterestRate
   
    // Calculates MonthlyInterest = balance * monthlyInterestRate
    public double getMonthlyInterest(){
        return (balance * getMonthlyInterestRate());
    } //getMonthlyInterest
   
    // Method for depositing money into balance
    public void deposit(double amount){
        this.balance = balance + amount;
    }// deposit
   
    // Method for withdrawing money from balance
    public void withdraw(double amount){
        this.balance = balance - amount;
    }// withdraw
}
