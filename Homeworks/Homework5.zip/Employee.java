public class Employee extends Person {
	private int office;
	private int salary;
	private MyDate dateHired;
	
	// constructor 
	
	public Employee(String name, String address, String phoneNum, String email, int office, int salary)
	{
		super(name, address, phoneNum, email);
		this.office = office;
		this.salary = salary;
		this.dateHired = new MyDate();
	}
	
	// setter functions
	
	public void setOffice(int office)
	{
		this.office = office;
	}
	
	public void setSalary(int salary)
	{
		this.salary = salary;
	}
	
	public void setDateHired()
	{
		dateHired = new MyDate();
	}
	
	// getter functions
	
	public int getOffice()
	{
		return office;
	}
	
	public int getSalary()
	{
		return salary;
	}
	
	public int getDateHired() 
	{
		return dateHired.getMonth() + '/' + dateHired.getDay() + '/' + dateHired.getYear();
	}
	
	// overriding toString function
	
	public String toString()
	{
		String statement = super.toString() + "\nOffice: " + office + "\nSalary: " + salary + "\nDate Hired: " + getDateHired();
		return statement;
	}
}
