
public class Staff extends Employee{
	private String title;
	
	// constructor
	
	public Staff(String name, String address, String phoneNum, String email, int office, int salary, String title)
	{
		super(name, address, phoneNum, email, office, salary);
		this.title = title;
	}
	
	// getter functions
	
	public String getTitle() 
	{
		return title;
	}
	
	// setter functions
	
	public void setTitle(String title)
	{
		this.title = title;
	}
	
	// overwriting the toString function
	
	public String toString()
	{
		String statement = super.toString() + "\nTitle: " + title;
		return statement;
	}
}
