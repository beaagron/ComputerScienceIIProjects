public class Student extends Person{
	static String status;
	
	// constructor
	
	public Student(String name, String address, String phoneNum, String email, String status)
	{
		super(name, address, phoneNum, email);
		this.status = status;
	}
	
	// setter function
	
	public void setStatus(String status)
	{
		this.status = status;
	}
	
	// getter function
	
	public String getStatus()
	{
		return status;
	}
	
	// overriding toString function
	
	public String toString()
	{
		String statement = super.toString() + "\nStatus: " + getStatus();
		return statement;
	}
}
