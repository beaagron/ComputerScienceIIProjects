import java.util.Scanner;

public class Exercise11_02 {
	
	public static void main(String [] args) {
		Person person1 = new Person("Bea", "123 Main Street", "(123) 456 - 7890", "beaagron@gmail.com");
		Student student1 = new Student("William", "653 Rutford Ave.", "(352) - 345 - 8642", "williamn@gmail.com", "Senior");
		Employee employee1 = new Employee("Jeanette", "543 Copper Ave.", "(345) 900 - 1855", "jeanettea@gmail.com", 41, 125000);
		Faculty faculty1 = new Faculty("John", "600 Campbell Rd.", "(724) 306 - 2000", "johns@gmail.com", 75, 90000, "MWF 9AM - 10AM", "Professor");
		Staff staff1 = new Staff("Bob", "1300 Synergy Ave.", "(512) 542 - 7422", "bobby@gmail.com", 25, 80000, "Teaching Assistant");
		
		// testing the toString function of each class
		
		System.out.println(person1.toString());
		System.out.println(student1.toString());
		System.out.println(employee1.toString());
		System.out.println(faculty1.toString());
		System.out.println(staff1.toString());
		
	}
}