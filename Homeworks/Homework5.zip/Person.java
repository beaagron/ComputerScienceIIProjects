public class Person {
	private String name, address, phoneNum, email;
	
	// constructor 
	
	public Person(String name, String address, String phoneNum, String email)
	{
		this.name = name;
		this.address = address;
		this.phoneNum = phoneNum;
		this.email = email;
	}
	
	// all setter functions
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setAddress(String address)
	{
		this.address = address;
	}
	
	public void setPhoneNum(String phoneNum)
	{
		this.phoneNum = phoneNum;
	}
	
	public void setEmail(String email)
	{
		this.email = email;
	}
	
	// all getter functions
	
	public String getName()
	{
		return name;
	}
	
	public String getAddress()
	{
		return address;
	}
	
	public String getPhoneNum()
	{
		return phoneNum;
	}
	
	public String getEmail()
	{
		return email;
	}
	
	// toString method returning the values
	
	public String toString() 
	{
		String statement = "\nName: " + name + "\nAddress: " + address + "\nPhone Number: " + phoneNum + "\nEmail: " + email;
		
		return statement;
	}
}
