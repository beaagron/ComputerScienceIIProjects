import java.util.ArrayList;
import java.util.Scanner;

public class Exercise11_12 {
	
	public static double sum(ArrayList<Double> list)
	{
		double total = 0;
		
		// adding all elements in array
		
		for(int i = 0; i < list.size(); i++)
		{
			total += list.get(i);
		}
		
		return total;
	}
	
	public static void main(String [] args)
	{
		Scanner input = new Scanner(System.in);
		ArrayList<Double> list = new ArrayList<Double>();
		
		// asking user for numbers and adding them to the list
		
		System.out.print("Enter 5 numbers: ");
		for(int i = 0; i < 5; i++)
		{
			list.add(input.nextDouble());
		}
		
		// running through function and displaying results
		
		System.out.println("The total sum is " + sum(list));
	}
}