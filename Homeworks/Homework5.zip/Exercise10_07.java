import java.util.Scanner;

public class Exercise10_07 {
	
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		Account[] allAccounts = new Account[10];
		int userChoice, ID;
		boolean systemOn = true;
		
		// initializing all 10 accounts to have $100
		
		for(int i = 0; i < allAccounts.length; i++)
		{
			allAccounts[i] = new Account(i, 100.00);
		}
		
		while(systemOn == true)
		{
			// entering an ID number to access an account
			
			System.out.print("Enter an ID: ");
			ID = input.nextInt();
			
			// input validation for the ID number 
			
			while((ID < 1) || (ID > 10))
			{
				System.out.print("Please enter a valid ID number: ");
				ID = input.nextInt();
			}
			
			// displaying the menu
			
			do 
			{
				System.out.println("Welcome #" + ID + ", enter a number:");
				System.out.println("1: View current balance");
				System.out.println("2: Withdraw money");
				System.out.println("3: Deposit money");
				System.out.println("4: Exit menu");
				
				userChoice = input.nextInt();
				
				// performing action based on userChoice in menu
				
				if(userChoice == 1)
				{
					System.out.println("Your balance is " + allAccounts[ID - 1].getBalance() + "$");
				}
				
				if(userChoice == 2)
				{
					double withdrawAmt;
					System.out.print("How much would you like to withdraw: ");
					
					withdrawAmt = input.nextDouble();
					allAccounts[ID - 1].withdraw(withdrawAmt);
					
					System.out.println("Withdrawal was successful");
				}
				
				if(userChoice == 3)
				{
					System.out.println("How much would you like to deposit: ");
					
					double depositAmt = input.nextDouble();
					allAccounts[ID - 1].deposit(depositAmt);
					
					System.out.println("Deposit was successful");
				}
				
			}while(userChoice != 4);
		}
	}
}