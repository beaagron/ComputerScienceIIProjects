import java.util.ArrayList;
import java.util.Scanner;

public class Exercise11_11 {
	
	public static void sort(ArrayList<Integer> list)
	{
		// sorting in increasing order
		
		for(int i = 0; i < 4; i++)
		{
			for(int j = 0; j < 4 - i; j++)
			{
				if(list.get(j) > list.get(j + 1))
				{
					int temp = list.get(j);
					list.set(j, list.get(j + 1));
					list.set(j + 1, temp);
				}
			}
		}
	}
	
	public static void main(String [] args)
	{
		Scanner input = new Scanner(System.in);
		ArrayList<Integer> list = new ArrayList<Integer>();
		
		// asking user for numbers and filling array list with the numbers
		
		System.out.print("Enter 5 numbers: ");
		
		for(int i = 0; i < 5; i++)
		{
			list.add(input.nextInt());
		}
		
		// running list through function and displaying result
		
		sort(list);
		System.out.println(list.toString());
		
		
	}
}