public class Faculty extends Employee{
	private String officeHrs, rank;
	
	// constructor
	
	public Faculty(String name, String address, String phoneNum, String email, int office, int salary, String officeHrs, String rank)
	{
		super(name, address, phoneNum, email, office, salary);
		this.officeHrs = officeHrs;
		this.rank = rank;
	}
	
	// setter functions
	
	public void setOfficeHrs(String officeHrs)
	{
		this.officeHrs = officeHrs;
	}
	
	public void setRank(String rank)
	{
		this.rank = rank;
	}
	
	// getter functions
	
	public String getOfficeHrs()
	{
		return officeHrs;
	}
	
	public String getRank()
	{
		return rank;
	}
	
	// overriding the toString function
	
	public String toString()
	{
		String statement = super.toString() + "\nOffice hours: " + officeHrs + "\nRank: " + rank;
		return statement;
	}
}
