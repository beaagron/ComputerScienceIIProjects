
public class Rectangle extends GeometricObject implements Comparable<Rectangle>{
	
	private double width, height;
	
	public Rectangle() {
		
	}
	
	public Rectangle(double w, double h)
	{
		this.width = w;
		this.height = h;
	}
	
	public Rectangle(double w, double h, String c, boolean f) 
	{
		this.width = w;
		this.height = h;
		setColor(c);
		setFilled(f);
	}
	
	public double getWidth() 
	{
		return width;
	}
	
	public double getHeight()
	{
		return height;
	}
	
	public void setWidth(double w)
	{
		this.width = w;
	}
	
	public void setHeight(double h)
	{
		this.height = h;
	}
	
	@Override
	public double getArea()
	{
		return width * height;
	}
	
	@Override 
	public double getPerimeter()
	{
		return (2 * width) + (2 * height);
	}
	
	@Override
	public int compareTo(Rectangle rect)
	{
		if(getArea() > rect.getArea())
		{
			return 1;
		}
		else if(getArea() < rect.getArea())
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	
	@Override
	public boolean equals(Object rect)
	{
		return this.compareTo((Rectangle)rect) == 0;
	}
	
	@Override
	public String toString()
	{
		String statement = super.toString() + "\nWidth: " + width + "\nHeight: " + height + "\nArea: " + getArea() + "\nPerimeter: " + getPerimeter();
		return statement;
	}

}
