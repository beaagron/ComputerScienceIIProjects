import java.util.*;

public class Exercise13_10 {
	
	public static void main(String [] args)
	{
		
		// creating three test cases
		
		Rectangle test1 = new Rectangle(3, 5, "black", true);
		Rectangle test2 = new Rectangle(3, 3, "black", false);
		Rectangle test3 = new Rectangle(8.4, 13.5, "pink", false);
		
		// testing getter and setter functions
		
		System.out.println("test1 area: " + test1.getArea());
		System.out.println("test2 area: " + test2.getArea());
		System.out.println("test3 area: " + test3.getArea());
		
		System.out.println("test1 height: " + test1.getHeight());
		System.out.println("test2 height: " + test2.getHeight());
		test2.setHeight(5);
		System.out.println("test2 height is now: " + test2.getHeight());
		System.out.println("test3 height: " + test3.getHeight());
		
		System.out.println("test1 perimeter: " + test1.getPerimeter());
		System.out.println("test2 perimeter: " + test2.getPerimeter());
		System.out.println("test3 perimeter: " + test3.getPerimeter());
		
		// testing the equals function
		
		if(test1.equals(test2))
		{
			System.out.println("test1 is equal to test2");
		}
		else
		{
			System.out.println("test1 is not equal to test2");
		}
		
		if(test1.equals(test3))
		{
			System.out.println("test1 is equal to test3");
		}
		else
		{
			System.out.println("test1 is equal to test3");
		}
		
	}
}