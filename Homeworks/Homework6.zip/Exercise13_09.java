import java.util.*;

public class Exercise13_09 {
	
	public static void main(String [] args)
	{
		
		// creating three test cases
		
		Circle test1 = new Circle(5, "pink", true);
		Circle test2 = new Circle(2, "pink", true);
		Circle test3 = new Circle(4, "blue", false);
		
		// printing and testing the getter and setter functions
		
		System.out.println("test1 radius: " + test1.getRadius());
		System.out.println("test2 radius: " + test2.getRadius());
		test2.setRadius(5);
		System.out.println("test2 radius is now: " + test2.getRadius());
		System.out.println("test3 radius: " + test3.getRadius());
		
		System.out.println("test1 area: " + test1.getArea());
		System.out.println("test2 area: " + test2.getArea());
		System.out.println("test3 area: " + test3.getArea());
		
		System.out.println("test1 perimeter: " + test1.getPerimeter());
		System.out.println("test2 perimeter: " + test2.getPerimeter());
		System.out.println("test3 perimeter: " + test3.getPerimeter());
		
		// testing the equals function with the test cases
		
		if(test1.equals(test2))
		{
			System.out.println("test 1 is equal to test 2");
		}
		else
		{
			System.out.println("test 1 does not equal test 2");
		}
		
		if(test2.equals(test3))
		{
			System.out.println("test 2 is equal to test 3");
		}
		else
		{
			System.out.println("test 2 does not equal test 3");
		}
	}
}