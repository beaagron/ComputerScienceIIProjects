
public class Circle extends GeometricObject implements Comparable<Circle>{

	private double radius;
	
	public Circle() {
	}
	
	public Circle(double r)
	{
		this.radius = r;
	}
	
	public Circle(double r, String c, boolean f)
	{
		this.radius = r;
		setColor(c);
		setFilled(f);
	}
	
	public void setRadius(double r)
	{
		this.radius = r;
	}
	
	public double getRadius()
	{
		return radius;
	}
	
	public double getDiameter()
	{
		return 2 * radius;
	}
	
	@Override
	public double getArea()
	{
		return radius * radius * Math.PI;
	}
	
	@Override
	public double getPerimeter()
	{
		return 2 * radius * Math.PI;
	}
	
	@Override
	public boolean equals(Object circle)
	{
		return this.compareTo((Circle)circle) == 0;
	}
	
	@Override
	public int compareTo(Circle circle)
	{
		if(this.radius > circle.radius)
		{
			return 1;
		}
		else if(this.radius < circle.radius)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	
	@Override
	public String toString()
	{
		String statement = super.toString() + "\nDate created: " + getDateCreated() + "\nRadius: " + radius;
		return statement;
	}
}
