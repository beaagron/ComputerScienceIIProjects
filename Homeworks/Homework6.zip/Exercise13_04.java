import java.util.*;

public class Exercise13_04 {
	
	public static void main(String [] args)
	{
		String [] months = {"January","February","March","April","May","June","July","August","September","October","November","December"};
		int [] days = {0,31,28,31,30,31,30,31,31,30,31,30,31};
		int year = Integer.parseInt(args[1]);
		int month = Integer.parseInt(args[0]);
		
		// detmermining if it is a leap year by running method
		
		if(month == 2 && leapYear(year))
		{
			days[month] = 29;
		}
		
		// printing out header and calendar
		
		System.out.println(" " + months[month] + " " + year);
		System.out.print(" Sun Mon Tue Wed Thu Fri Sat");
		int day = startDay(month, 1, year);
		for (int i = 0; i < day; i++)
		{
			System.out.print(" ");
		}
		for(int i = 1; i <= days[month]; i++)
		{
			System.out.printf("%2d", i);
			
			if(((i + day) % 7 == 0) || (i == days[month]))
			{
				System.out.println();
			}
		}
	}
	
	public static int startDay(int month, int day, int year)
	{
		int yr = year - (14 - month) / 12;
		int leap = yr + yr/4 - yr/100 + yr/400;
		int m = month + 12 * ((14 - month) / 12) - 2;
		int days = (day + 1 + (31 * m) / 12) % 7;
		
		return days;
		
	}
	
	public static boolean leapYear(int year)
	{
		if((year % 4 == 0) && (year % 100 != 0))
		{
			return true;
		}
		else if(year % 400 == 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	
}