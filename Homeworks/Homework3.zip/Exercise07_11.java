import java.util.Scanner;

public class Exercise07_11 {
	
	public static double mean(double [] x) {
		double mean, sum = 0;
		
		for(int i = 0; i < x.length; i++)
		{
			sum += x[i];
		}
		
		mean = (sum / x.length);
		
		return mean;
	}
	
	public static double deviation(double [] x) {
		double deviation, numerator, sum = 0;
		
		for(int i = 0; i < x.length; i++)
		{
			sum += (Math.pow((mean(x) - x[i]), 2));
		}
		
		deviation = Math.sqrt(sum / (x.length - 1));
		
		return deviation;
	}
	
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		double [] list = new double[10];
		double mean, deviation;
		
		// prompting user and storing doubles into list
		
		System.out.print("Enter ten numbers: ");
		for(int i = 0; i < list.length; i++)
		{
			list[i] = input.nextDouble();
		}
		
		// running list through methods and printing results
		
		mean = mean(list);
		deviation = deviation(list);
		System.out.printf("The mean is %.2f\n", mean);
		System.out.printf("The standard deviation is %.5f\n", deviation);
	}
	
}