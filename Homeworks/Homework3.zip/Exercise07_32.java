import java.util.Scanner;

public class Exercise07_32 {
	
	public static int partiton(int [] list) {
		int smallNums = 0;
		int pivot = list[0];
		int largeNums = (list.length - 1);
		
		while(smallNums < largeNums)
		{
			if(pivot < list[smallNums + 1])
			{
				
				// if number is larger than pivot number, move it to the left side
				
				int temp = list[largeNums];
				list[largeNums] = list[smallNums + 1];
				list[smallNums + 1] = temp;

				largeNums--;
				
			}
			else
			{
				
				// otherwise, keep moving the pivot number closer to the middle
				
				list[smallNums] = list[smallNums + 1];
				list[smallNums + 1] = pivot;
				
				smallNums++;
			
			}
		}
		
		return smallNums;
		
	}
	
	public static void main(String [] args) {
		
		Scanner input = new Scanner(System.in);
		
		// asking user and reading in the numbers into a list
		
		System.out.print("Enter list: ");
		int [] list = new int[input.nextInt()];

		for(int i = 0; i < list.length; i++)
		{
			list [i] = input.nextInt();
		}
		
		// running list through method that will partition list
		
		partiton(list);
		
		// returning the partitioned list by printing in console
		
		System.out.print("After the partition, the list is ");
		for(int i = 0; i < list.length; i++)
		{
			System.out.print(list[i] + " ");
		}
	}
}