import java.util.Scanner;

public class Exercise07_19 {
	
	public static boolean isSorted(int [] list) {
		
		for(int i = 0; i < list.length - 1; i++)
		{
			if(list[i] > list[i + 1])
			{
				return false;
			}
		}
		
		return true;
	}
	
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		boolean sort;
		
		System.out.print("Enter list: ");
		int [] list = new int[input.nextInt()];
		
		for(int i = 0; i < list.length; i++)
		{
			list [i] = input.nextInt();
		}
		
		sort = isSorted(list);
		
		if(sort == true)
		{
			System.out.print("The list is already sorted");
		}
		else
		{
			System.out.print("This list is not sorted");
		}
		
		
	}
}