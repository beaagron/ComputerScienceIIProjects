public class Exercise07_16 {
	
	public static int linearSearch(int [] list, int key) {
		
		for(int i = 0; i < list.length; i++)
		{
			if(list[i] == key)
			{
				return i;
			}
		}
		
		return -1;
	}
	
	public static int binarySearch(int [] list, int key) {
		int low = 0, high = (list.length - 1);
		
		while(high >= low)
		{
			int mid = (low + high) / 2;
			if(key > mid)
			{
				low = mid + 1;
			}
			else if (key < mid)
			{
				high = mid - 1;
			}
			else
			{
				return mid;
			}
		}
		
		return -1;
	}
	
	public static void sorting(int [] list) {
		
		for(int i = 1; i < list.length; i++)
		{
			int move = list[i];
			int j = i - 1;
			
			while((j >= 0) && (list[i] > move))
			{
				list[j + 1] = list[j];
				j = j -1;
			}
			
			list[j + 1] = move;
		}
	}
	
	public static void main(String [] args) {
		
		// creating an array of 1000 elements and a random key
		
		int [] list = new int [100000];
		for(int i = 0; i < list.length; i++)
		{
			list[i] = (1 + (int)(Math.random() * 100000));
		}
		int key = (1 + (int)(Math.random() * 100000));
		
		// insertion sorting the array in ascending order
		
		sorting(list);
		
		// using linear search and showing execution time
		
		long startTime = (System.currentTimeMillis()) * 1000000;
		linearSearch(list, key);
		long endTime = (System.currentTimeMillis()) * 1000000;
		long executionTime = endTime - startTime;
		
		System.out.println("The execution time for linear search was " + executionTime);
		
		// using binary search and showing execution time
		
		startTime = (System.currentTimeMillis()) * 1000000;
		binarySearch(list, key);
		endTime = (System.currentTimeMillis()) * 1000000;
		executionTime = endTime - startTime;
		
		System.out.println("The execution time for binary search was " + executionTime);
	}
}