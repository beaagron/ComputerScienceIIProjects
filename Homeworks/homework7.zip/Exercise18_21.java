import java.util.Scanner;

public class Exercise18_21 {
	
	public static String total = "";
	
	public static String dec2bin(int value) {
		
		int convertedCurrentVal = value / 2;
		// determining the length of the value and how much needs to be recursively called
		if(convertedCurrentVal == 0)
		{
			total += (value % 2);
		}
		else
		{
			total += (value % 2);
			total = dec2bin(convertedCurrentVal);
		}
		
		return total;
	}
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int value;
		
		System.out.println("Enter a number to be converted into binary: ");
		value = input.nextInt();
		
		StringBuilder res = new StringBuilder(dec2bin(value));
		System.out.println(res.reverse());
	}
	
}