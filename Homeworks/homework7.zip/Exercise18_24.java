import java.util.Scanner;

public class Exercise18_24 {
	
	public static int hex2dec(String hexString) {
		int returnVal;
		int evalNum;
		
		if(hexString.length() == 1)
		{
			char conversion = hexString.charAt(0);
			int converted;
			if((conversion - '0') < 10)
			{
				converted = conversion - '0';
			}
			else
			{
				conversion = Character.toUpperCase(conversion);
				converted = conversion - 'A' + 10;
			}
			returnVal = converted;
		}
		else
		{
			
			char conversion = hexString.charAt(0);
			int converted;
			if((conversion - '0') < 10)
			{
				converted = conversion - '0';
			}
			else
			{
				conversion = Character.toUpperCase(conversion);
				converted = conversion - 'A' + 10;
			}
			
			returnVal = ((int)Math.pow(16, hexString.length() - 1) * converted) + hex2dec(hexString.substring(1));
		}
		
		return returnVal;
	}
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String value;
		
		System.out.println("Enter a hex number to be converted into decimal: ");
		value = input.next();
		
		System.out.println(hex2dec(value));
	}
}