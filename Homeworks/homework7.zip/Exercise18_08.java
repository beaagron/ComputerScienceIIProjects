import java.util.Scanner;

public class Exercise18_08 {
	
	public static void reverseDisplay(int value)
	{
		
		// determining the number of digits in the value
		if(value >= 10)
		{
			
			// using mod 10 to isolate the numbers and recursively call the reverseDisplay function
			
			int newValue = value % 10;
			System.out.print(newValue);
			reverseDisplay(value / 10);
		}
		else
		{
			System.out.println(value);
		}
		
	}
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter a number to be printed reversely:");
		int val = input.nextInt();
		
		reverseDisplay(val);
	}
}