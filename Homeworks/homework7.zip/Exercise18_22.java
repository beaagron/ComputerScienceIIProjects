import java.util.Scanner;

public class Exercise18_22 {
	
	public static String total = "";
	
	public static String dec2hex(int value) {
		
		int currentVal = value % 16;
		String carryover = "";
		
		// determining the length of the value and how much needs to be recursively called
		if(currentVal >= 10)
		{
			carryover = String.valueOf((char)('A' + currentVal % 10));
		}
		else
		{
			carryover = String.valueOf(currentVal);
		}
		
		if((value / 16) != 0)
		{
			total += carryover;
			total = dec2hex(value/16);
		}
		else
		{
			total += carryover;
		}
		
		return total;
	}
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int value;
		
		System.out.println("Enter a number to be converted into hex: ");
		value = input.nextInt();
		
		System.out.println(dec2hex(value));
	}
	
}