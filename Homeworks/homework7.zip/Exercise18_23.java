import java.util.Scanner;

public class Exercise18_23 {

	public static int bin2dec(String binaryString) {
		
		int evalNum;
		int returnVal;
		
		if(binaryString.charAt(0) == '1')
		{
			evalNum = 1;
		}
		else
		{
			evalNum = 0;
		}
		
		if(binaryString.length() == 1)
		{
			returnVal = evalNum;
		}
		else
		{
			returnVal = ((int)Math.pow(2, binaryString.length() - 1) * evalNum) + bin2dec(binaryString.substring(1));
		}
		
		return returnVal;
	}
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String value;
		
		System.out.println("Enter a binary number to be converted into decimal: ");
		value = input.next();
		
		System.out.println(bin2dec(value));
	}
	
}