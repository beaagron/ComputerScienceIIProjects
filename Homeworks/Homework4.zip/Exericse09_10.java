import java.util.Scanner;

public class Exericse09_10 {
	
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		int a, b ,c;
		
		System.out.print("Enter an a, b, and c: ");
		
		a = input.nextInt();
		b = input.nextInt();
		c = input.nextInt();
		
		QuadraticEquation test1 = new QuadraticEquation(a, b, c);
		
		if(test1.getDiscriminant() > 0)
		{
			System.out.println("The first root is " + test1.getRoot1() + " and the second is " + test1.getRoot2());
		}
		else if(test1.getDiscriminant() == 0)
		{
			if(test1.getRoot1() > 0)
			{
				System.out.println("The first root is " + test1.getRoot1() + " and the second is zero");
			}
			else
			{
				System.out.println("The first root is zero and the second is " + test1.getRoot2());
			}
		}
		else
		{
			System.out.println("The equation has no roots.");
		}
		
	}
}