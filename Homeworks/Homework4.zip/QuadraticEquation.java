
public class QuadraticEquation {
	private int a;
	private int b;
	private int c;
	
	public QuadraticEquation(int A, int B, int C) {
		a = A;
		b = B;
		c = C;
	}
	
	public int getA() { return a; }
	public int getB() { return b; }
	public int getC() { return c; }
	
	public int getDiscriminant() { return ((int) (Math.pow(b, 2)) - 4 * a * c); }
	
	public int getRoot1() {
		int discriminant = getDiscriminant();
		int numerator, denominator;
		
		if(!(discriminant < 0))
		{
			numerator = (int) (-b + Math.sqrt(discriminant));
			denominator = (2 * a);
			
			return (numerator / denominator);
		}
		else
		{
			return 0;
		}
	}
	
	public int getRoot2() {
		int discriminant = getDiscriminant();
		int numerator, denominator;
		
		if(!(discriminant < 0))
		{
			numerator = (int) (-b - Math.sqrt(discriminant));
			denominator = (2 * a);
			
			return (numerator / denominator);
		}
		else
		{
			return 0;
		}
	}
}
