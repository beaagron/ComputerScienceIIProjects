
public class Rectangle {
	private double height;
	private double width;
	
	// no-arg constructor that creates a default rectangle
	
	public Rectangle() {
		width = 1;
		height = 1;
	}
	
	// constructor that creates a rectangle with specified width and height
	
	public Rectangle(double w, double h) {
		width = w;
		height = h;
	}
	
	// getter functions to display width and height
	
	public double getWidth() { return width; };
	
	public double getHeight() { return height; }
	
	// returns the area of the rectangle
	
	public double getArea() { return (width * height); }
	
	// returns the perimeter of the rectangle 
	
	public double getPerimeter() { return ((width * 2) + (height * 2));}
	
}
