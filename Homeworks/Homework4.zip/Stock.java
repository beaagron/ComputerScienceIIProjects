public class Stock {

	private String symbol;
	private String name;
	private double previousClosingPrice;
	private double currentPrice;
	
	// constructor with specifiers
	
	public Stock(String s, String n) {
			symbol = s;
			name = n;
			previousClosingPrice = 0;
			currentPrice = 0;
	}
	
	public void setCurrentPrice (double price) {
		currentPrice = price;
	}
	
	public void setPreviousClosingPrice (double price) {
		previousClosingPrice = price;
	}
	
	// returns the percentage changed from previous price to current
	
	public double getChangePrecent() {
		return ((currentPrice - previousClosingPrice) / currentPrice);
	}
	
}
