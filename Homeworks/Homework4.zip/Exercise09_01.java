public class Exercise09_01 {
	
	public static void main(String [] args) {
		
		double area, perimeter;
		
		/*
		
		// testing default constructor
		
		Rectangle test1 = new Rectangle();
		
		area = test1.getArea();
		perimeter = test1.getPerimeter();
		
		System.out.println("Area for test1 is " + area);
		System.out.println("Perimeter for test1 is " + perimeter);
		
		*/
		
		// testing specified argument constructor
		
		Rectangle test2 = new Rectangle(4, 40);
		
		area = test2.getArea();
		perimeter = test2.getPerimeter();
		
		System.out.println("Width for test2 is " + test2.getWidth());
		System.out.println("Height for test2 is " + test2.getHeight());
		System.out.println("Area for test2 is " + area);
		System.out.println("Perimeter for test2 is " + perimeter);
		
		Rectangle test3 = new Rectangle(3.5, 35.9);
		
		area = test2.getArea();
		perimeter = test2.getPerimeter();
		
		System.out.println("Width for test3 is " + test3.getWidth());
		System.out.println("Height for test3 is " + test3.getHeight());
		System.out.println("Area for test3 is " + area);
		System.out.println("Perimeter for test3 is " + perimeter);
	}
}