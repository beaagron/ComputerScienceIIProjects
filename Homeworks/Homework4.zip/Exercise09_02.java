public class Exercise09_02 {
	
	public static void main(String [] args) {
		double percent;
		
		Stock test1 = new Stock("ORCL", "Orcale Corporation");
		
		test1.setPreviousClosingPrice(34.5);
		test1.setCurrentPrice(34.35);
		
		percent = test1.getChangePrecent();
		
		System.out.println("The price-change percentage is " + percent);
		
	}
}